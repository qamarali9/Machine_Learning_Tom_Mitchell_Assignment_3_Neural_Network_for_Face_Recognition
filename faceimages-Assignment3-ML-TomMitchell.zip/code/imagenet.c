/*
 ******************************************************************
 * HISTORY
 * 15-Oct-94  Jeff Shufelt (js), Carnegie Mellon University
 *      Prepared for 15-681, Fall 1994.
 *
 ******************************************************************
 */

#include <stdio.h>
#include <pgmimage.h>
#include <backprop.h>

extern void exit();

#define TARGET_HIGH 0.9
#define TARGET_LOW 0.1


/*** This is the target output encoding for a network with one output unit.
     It scans the image name, and if it's an image of me (js) then
     it sets the target unit to HIGH; otherwise it sets it to LOW.
     Remember, units are indexed starting at 1, so target unit 1
     is the one to change....  ***/

load_target(img, net)
IMAGE *img;
BPNN *net;
{
  int scale;
  char userid[40], head[40], expression[40], eyes[40], photo[40];

  userid[0] = head[0] = expression[0] = eyes[0] = photo[0] = '\0';

  /*** scan in the image features ***/
  sscanf(NAME(img), "%[^_]_%[^_]_%[^_]_%[^_]_%d.%[^_]",
    userid, head, expression, eyes, &scale, photo);

  //if (!strcmp(userid, "glickman")) 
  // if (!strcmp(eyes,"sunglasses")){
  //  net->target[1] = TARGET_HIGH;   has sunglasses, set target to HIGH 
  // } else {
  //  net->target[1] = TARGET_LOW;   /* no shades, set it to LOW */
  // }

/*
an2i  at33  boland  bpm  ch4f  cheyer  choon  danieln  glickman  karyadi  kawamura  kk49  megak  mitchell  night  phoebe  saavik  steffi  sz24  tammo
*/

  // int i = 0;
  // for(i=1;i<=20;i++){net->target[i]=0.005;}
  // if (!strcmp(userid, "an2i")){
  //   net->target[1] = 0.905;  /* it's an2i, set target[1] to HIGH */
  // } else if (!strcmp(userid, "at33")){
  //   net->target[2] = 0.905;   /* it's at33, set target[2] to HIGH */
  // }else if (!strcmp(userid, "boland")){
  //   net->target[3] = 0.905;  /* it's boland, set target[3] to HIGH */
  // } else if (!strcmp(userid, "bpm")){
  //   net->target[4] = 0.905;   /* it's bpm, set target[4] to HIGH */
  // }else if (!strcmp(userid, "ch4f")){
  //   net->target[5] = 0.905;  /* it's ch4f, set target[5] to HIGH */
  // }else if (!strcmp(userid, "cheyer")){
  //   net->target[6] = 0.905;  /* it's cheyer, set target[6] to HIGH */
  // } else if (!strcmp(userid, "choon")){
  //   net->target[7] = 0.905;   /* it's choon, set target[7] to HIGH */
  // }else if (!strcmp(userid, "danieln")){
  //   net->target[8] = 0.905;  /* it's danieln, set target[8] to HIGH */
  // } else if (!strcmp(userid, "glickman")){
  //   net->target[9] = 0.905;   /* it's glickman, set target[9] to HIGH */
  // }else if (!strcmp(userid, "karyadi")){
  //   net->target[10] = 0.905;   it's karyadi, set target[10] to HIGH 
  // }else if (!strcmp(userid, "kawamura")){
  //   net->target[11] = 0.905;  /* it's kawamura, set target[11] to HIGH */
  // } else if (!strcmp(userid, "megak")){
  //   net->target[12] = 0.905;   /* it's megak, set target[12] to HIGH */
  // }else if (!strcmp(userid, "mitchell")){
  //   net->target[13] = 0.905;  /* it's mitchell, set target[13] to HIGH */
  // } else if (!strcmp(userid, "night")){
  //   net->target[14] = 0.905;   /* it's night, set target[14] to HIGH */
  // }else if (!strcmp(userid, "phoebe")){
  //   net->target[15] = 0.905;  /* it's phoebe, set target[15] to HIGH */
  // }else if (!strcmp(userid, "cheyer")){
  //   net->target[16] = 0.905;  /* it's cheyer, set target[16] to HIGH */
  // } else if (!strcmp(userid, "saavik")){
  //   net->target[17] = 0.905;   /* it's saavik, set target[17] to HIGH */
  // }else if (!strcmp(userid, "steffi")){
  //   net->target[18] = 0.905;  /* it's steffi, set target[18] to HIGH */
  // } else if (!strcmp(userid, "sz24")){
  //   net->target[19] = 0.905;   /* it's sz24, set target[19] to HIGH */
  // }else if (!strcmp(userid, "tammo")){
  //   net->target[20] = 0.905;  /* it's tammo, set target[20] to HIGH */
  // }

  int i = 0;
  for(i=1;i<=4;i++){net->target[i]=0.025;}
  if (!strcmp(head, "straight")){
     net->target[1] = 0.925;  /* pose is straight, set target[1] to HIGH */
   } else if (!strcmp(head, "up")){
     net->target[2] = 0.925;   /* pose is up, set target[2] to HIGH */
   }else if (!strcmp(head, "left")){
     net->target[3] = 0.925;  /* pose is left, set target[3] to HIGH */
   } else if (!strcmp(head, "right")){
     net->target[4] = 0.925;   /* pose is right, set target[4] to HIGH */
  }
}


/***********************************************************************/
/********* You shouldn't need to change any of the code below.   *******/
/***********************************************************************/

load_input_with_image(img, net)
IMAGE *img;
BPNN *net;
{
  double *units;
  int nr, nc, imgsize, i, j, k;

  nr = ROWS(img);
  nc = COLS(img);
  imgsize = nr * nc;;
  if (imgsize != net->input_n) {
    printf("LOAD_INPUT_WITH_IMAGE: This image has %d pixels,\n", imgsize);
    printf("   but your net has %d input units.  I give up.\n", net->input_n);
    exit (-1);
  }

  units = net->input_units;
  k = 1;
  for (i = 0; i < nr; i++) {
    for (j = 0; j < nc; j++) {
      units[k] = ((double) img_getpixel(img, i, j)) / 255.0;
      k++;
    }
  }
}
